/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

import service.TransService;
import serviceImpl.TransServiceImpl;
import sun.org.mozilla.javascript.internal.ast.NewExpression;
import utils.Dbutil;
import bean.TransInfo;

import com.mysql.jdbc.Connection;

import dao.TransDao;
import daoImpl.TransDaoImpl;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class Test4 {

	@Test
	public void test() {
		Connection con=Dbutil.getConnection();
		TransService transService = new TransServiceImpl();
		
		TransInfo t=new TransInfo();
		t.setAcctNo("7979");
		t.setMoney(400.0);
		t.setTransDate(new Date());
		t.setTransType("取款");
		t.setUserId("11111");
		
		
		try {
			transService.add(t);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
