/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package test;

import static org.junit.Assert.*;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import bean.User;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import daoImpl.UserDaoImpl;
import service.UserService;
import serviceImpl.UserServiceImpl;
import utils.Dbutil;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class Test1 {

	@Test
	public void test() {
		Connection con = Dbutil.getConnection();
		assertNotNull(con);
	}
	
	@Test
	public void test1(){ 
		UserService userService = new UserServiceImpl();
		User user = new User("1", "1", "1", "1", "1", "1", "1", 1);
		try {
			userService.register(user);
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}
	
	@Test
	public void test2(){
			String sql="select *from user where UserId="+99999+"";
			PreparedStatement ps=null;
			ResultSet rs = null;
			User user = new User();
			Connection con=Dbutil.getConnection();
			try {
				ps = (PreparedStatement) con.prepareStatement(sql);
				rs = ps.executeQuery();
				while(rs.next()){
					user.setUserId(rs.getString("UserId"));
					user.setPersonId(rs.getString("personId"));
					user.setUserName(rs.getString("userName"));
					user.setUserPwd(rs.getString("userPwd"));
					user.setOldPwd(rs.getString("oldPwd"));
					user.setPhone(rs.getString("phone"));
					user.setAddr(rs.getString("addr"));
					user.setUserType(rs.getInt("userType"));
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}finally{
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			System.out.println(user.getUserId());
			//return user;	
	}
	
}
