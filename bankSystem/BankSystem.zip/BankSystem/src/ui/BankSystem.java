/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package ui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

import utils.Container;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class BankSystem {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BankSystem window = new BankSystem();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public BankSystem() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("银行管理系统");
		frame.setBounds(100, 100, 500, 400);
		frame.setLocationRelativeTo(null);//设置居中
		
		JPanel mainJPanel=new JPanel(){
			/**
			 * 生成一个默认的序列化ID
			 */
			private static final long serialVersionUID = 4135011662261633632L;

			@Override
			protected void paintComponent(Graphics g) {
				// TODO 自动生成的方法存根
				super.paintComponent(g);
				ImageIcon icon=new ImageIcon(BankSystem.class.getResource("/image/2.png"));//生成背景图片
				//下面是设置根据上面得到的图片，画一个背景图片，相对于当前这个mainjpanel来说位置是0,0，大小就和mainjpanel一样大，不要观察
				g.drawImage(icon.getImage(), 0, 0, this.getWidth(), this.getHeight(), null);
				/*System.out.println(this.getWidth()+"hahh"+this.getHeight());*/
			}	
		};
		
		frame.getContentPane().add(mainJPanel, BorderLayout.CENTER);
		CardLayout card=new CardLayout();
		mainJPanel.setLayout(card);
		//这个是要做一个卡片布局，然后就在这个mainpanel上面加按钮，做成卡片布局
		JPanel loginPanel=new LoginPanel();
		loginPanel.setOpaque(false);//设置加在mianjpanle上面的这个登录界面透明
		JPanel regPanel=new RegPanel();
		regPanel.setOpaque(false);
		JPanel cardpanel = new CardPanel();
		cardpanel.setOpaque(false);
		JPanel cardAddPanel = new CardAddPanel();
		cardAddPanel.setOpaque(false);
		JPanel bankPanel = new BankPanel();
		bankPanel.setOpaque(false);
		
		mainJPanel.add(loginPanel,"loginPanel");
		mainJPanel.add(regPanel,"regPanel");//后面是取名
		mainJPanel.add(cardpanel,"cardpanel");
		mainJPanel.add(cardAddPanel,"cardAddPanel");
		mainJPanel.add(bankPanel,"bankPanel");
		
		Container.register("mainJPanel", mainJPanel);
		Container.register("loginPanel", loginPanel);
		Container.register("regPanel", regPanel);
		Container.register("cardpanel",cardpanel);
		Container.register("cardAddPanel", cardAddPanel);
		Container.register("bankPanel", bankPanel);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
