/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package ui;

import java.util.HashMap;
import java.util.Map;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import utils.XTabbedPanel;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class BankPanel extends JPanel {
 	/**
	 * 
	 */
	private static final long serialVersionUID = 39784602546129813L;
	private Map<String , JComponent> datas = new HashMap<String , JComponent>(); 
 	private JTable table;
	/**
	 * Create the panel.
	 */
	@SuppressWarnings("serial")
	public BankPanel() {
		setLayout(null);
		
		MoneyPanel moneyPanel = new MoneyPanel();
		SystemPanel systemPanel = new SystemPanel();
		datas.put("储蓄业务", moneyPanel);
		datas.put("系统管理", systemPanel);
		
		
		JSplitPane splitPane = new JSplitPane();
		splitPane.setBounds(0, 0, 558, 369);
		add(splitPane);
		
		final JTree bankMenu = new JTree();
		bankMenu.setModel(new DefaultTreeModel(
			new DefaultMutableTreeNode("银行管理系统") {
				{
					add(new DefaultMutableTreeNode("储蓄业务"));
					add(new DefaultMutableTreeNode("系统管理"));
				}
			}
		));
		splitPane.setLeftComponent(bankMenu);
		
		JSplitPane splitPane_1 = new JSplitPane();
		splitPane_1.setOrientation(JSplitPane.VERTICAL_SPLIT);
		splitPane_1.setDividerLocation(200);
		splitPane.setRightComponent(splitPane_1);
		
		final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		splitPane_1.setLeftComponent(tabbedPane);
		
		JScrollPane scrollPane = new JScrollPane();
		splitPane_1.setRightComponent(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
			},
			new String[] {
				"用户ID", "银行卡账号", "金额", "交易类型","交易日期"
			}
		));
		scrollPane.setViewportView(table);
		
		bankMenu.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				// TODO 自动生成的方法存根
				TreePath path = e.getPath();
				if(path==null){
					return;
				}
				bankMenu.setSelectionPath(path);
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) bankMenu.getLastSelectedPathComponent();
				if(node.isLeaf()){
					String name = path.getPathComponent(path.getPathCount()-1).toString();
					System.out.println(name);
					JComponent textPane=datas.get(name);
					if(textPane==null){
						textPane=new MoneyPanel();
						tabbedPane.addTab(name,null,textPane,null);
						tabbedPane.setTabComponentAt(tabbedPane.getTabCount()-1, new XTabbedPanel(tabbedPane));
						tabbedPane.setSelectedComponent(textPane);
						datas.put(name, textPane);	
					}else{
						if(textPane instanceof MoneyPanel){
							MoneyPanel mp = (MoneyPanel)textPane; 
							mp.refresh();
						}
						
						tabbedPane.addTab(name,null,textPane,null);
						tabbedPane.setTabComponentAt(tabbedPane.getTabCount()-1, new XTabbedPanel(tabbedPane));
						tabbedPane.setSelectedComponent(textPane);
					}
				}
								
			}
		});		
	}
	public JTable getTable() {
		return table;
	}
	public void setTable(JTable table) {
		this.table = table;
	}
	
	
	
}
