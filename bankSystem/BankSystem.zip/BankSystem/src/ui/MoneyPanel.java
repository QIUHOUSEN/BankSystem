/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package ui;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import service.AccountService;
import service.TransService;
import service.UserService;
import serviceImpl.AccountServiceImpl;
import serviceImpl.TransServiceImpl;
import serviceImpl.UserServiceImpl;
import sun.org.mozilla.javascript.internal.ast.NewExpression;
import utils.Container;
import bean.Account;
import bean.TransInfo;
import bean.User;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Date;
import java.util.List;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class MoneyPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8882988824748505926L;
	private JTextField balance;
	private JTextField money;
	private JTextField acctId;
	private JTextField name;
	private AccountService accountService = new AccountServiceImpl();
	private UserService userService = new UserServiceImpl();
	private TransService transService = new TransServiceImpl();
	
	/**
	 * Create the panel.
	 */
	public MoneyPanel() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("金额");
		lblNewLabel.setBounds(37, 38, 54, 15);
		add(lblNewLabel);
		
		JLabel label = new JLabel("余额");
		label.setBounds(37, 13, 54, 15);
		add(label);
		
		JLabel label_1 = new JLabel("对方账户");
		label_1.setBounds(37, 63, 54, 15);
		add(label_1);
		
		JLabel label_2 = new JLabel("对方姓名");
		label_2.setBounds(37, 88, 54, 15);
		add(label_2);
		
		JButton saveBtn = new JButton("存款");
		saveBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Account acct=(Account) Container.getValue("acct");
				User user=(User)Container.getValue("user");
				acct.setSaveMoney(acct.getSaveMoney()+Double.parseDouble(money.getText()));
				try {
					accountService.update(acct);
					TransInfo info=new TransInfo();
					info.setUserId(user.getUserId());
					info.setAcctNo(acct.getAcctId());
					info.setMoney(Double.parseDouble(money.getText()));
					info.setTransType("存款");
					info.setTransDate(new Date());
					transService.add(info);//存款后将这些信息存入数据库
					refresh();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		saveBtn.setBounds(10, 133, 93, 23);
		add(saveBtn);
		
		JButton withdrawBtn = new JButton("取款");
		withdrawBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Account acct=(Account) Container.getValue("acct");
				User user=(User)Container.getValue("user");
				if(acct.getSaveMoney()<Double.parseDouble(money.getText())){
					JOptionPane.showMessageDialog(null, "账户余额不足");
				}else{
					acct.setSaveMoney(acct.getSaveMoney()-Double.parseDouble(money.getText()));
				}
				try {
					accountService.update(acct);
					TransInfo info=new TransInfo();
					info.setUserId(user.getUserId());
					info.setAcctNo(acct.getAcctId());
					info.setMoney(Double.parseDouble(money.getText()));
					info.setTransType("取款");
					info.setTransDate(new Date());
					transService.add(info);//存款后将这些信息存入数据库
					refresh();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});
		withdrawBtn.setBounds(129, 133, 93, 23);
		add(withdrawBtn);
		
		JButton transBtn = new JButton("转账");
		transBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {//对方账户：
					Account acct = accountService.findByAccountId(acctId.getText());
					if(acct==null){
						JOptionPane.showMessageDialog(null, "对方账户不存在");
					}else{
						String userId=acct.getUserId();//通过这个账户的用户id找到这个人
						User user= userService.fingUserById(userId);
						if(name.getText().equals(user.getUserName())){
							//这是自己账户
							Account acct2=(Account) Container.getValue("acct");
							if(acct2.getSaveMoney()<Double.parseDouble(money.getText())){
								JOptionPane.showMessageDialog(null, "自己这方卡里钱不够");
							}else{
								acct2.setSaveMoney(acct2.getSaveMoney()-Double.parseDouble(money.getText()));
								acct.setSaveMoney(acct.getSaveMoney()+Double.parseDouble(money.getText()));
								try {
									accountService.transfer(acct,acct2);
									TransInfo info=new TransInfo();
									info.setUserId(user.getUserId());
									info.setAcctNo(acct.getAcctId());
									info.setMoney(Double.parseDouble(money.getText()));
									info.setTransType("转账");
									info.setTransDate(new Date());
									transService.add(info);//存款后将这些信息存入数据库
									refresh();
								} catch (Exception e1) {
									e1.printStackTrace();
								}
							}
							
						}else{
							JOptionPane.showMessageDialog(null, "收账放姓名不对");
						}
						
					}
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
				
			}
		});
		transBtn.setBounds(244, 133, 93, 23);
		add(transBtn);
		
		balance = new JTextField();
		balance.setEditable(false);
		balance.setBounds(129, 10, 102, 21);
		add(balance);
		balance.setColumns(10);
		
		money = new JTextField();
		money.setBounds(129, 35, 102, 21);
		add(money);
		money.setColumns(10);
		
		acctId = new JTextField();
		acctId.setBounds(129, 63, 102, 21);
		add(acctId);
		acctId.setColumns(10);
		
		name = new JTextField();
		name.setBounds(129, 94, 102, 21);
		add(name);
		name.setColumns(10);
		
		JButton balanceBtn = new JButton("查询余额");
		balanceBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refresh();
			}
		});
		balanceBtn.setBounds(356, 133, 93, 23);
		add(balanceBtn);

	}

	public void refresh() {
		Account acct=(Account) Container.getValue("acct");
		String acctIds=acct.getAcctId();
		try {
			acct=accountService.findByAccountId(acctIds);//再次从数据库里面读取更新的一个账户
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		balance.setText(acct.getSaveMoney()+"");
		money.setText("");
		acctId.setText("");
		name.setText("");
		try {
			List<TransInfo> infos=transService.findAll();
			Object[][] datas=new Object[infos.size()][5];
			for(int i=0;i<infos.size();i++){
				datas[i][0]=infos.get(i).getUserId();
				datas[i][1]=infos.get(i).getAcctNo();
				datas[i][2]=infos.get(i).getMoney();
				datas[i][3]=infos.get(i).getTransType();
				datas[i][4]=infos.get(i).getTransDate();
			}
							
			BankPanel bankPanel = (BankPanel) Container.getValue("bankPanel");
			bankPanel.getTable().setModel(new DefaultTableModel(
					datas,
						new String[] {
							"用户ID", "银行卡账号", "金额", "交易类型","交易日期"
						}
			));
						
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
