/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package ui;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;

import java.awt.CardLayout;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

import bean.Account;
import bean.User;
import service.AccountService;
import serviceImpl.AccountServiceImpl;
import utils.Container;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class CardAddPanel extends JPanel {
 	private JTextField acctId;
 	private JTextField saveMoney;
 	private JTextField saveYear;
 	private AccountService accountService = new AccountServiceImpl();
	JComboBox acctType = new JComboBox();
	JComboBox saveType = new JComboBox();
	
	/**
	 * Create the panel.
	 */
	public CardAddPanel() {
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new LineBorder(new Color(128, 128, 128), 2, true), "\u57FA\u672C\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, Color.RED));
		panel.setBounds(47, 10, 381, 208);
		add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("卡号");
		label.setBounds(30, 27, 54, 15);
		panel.add(label);
		
		acctId = new JTextField();
		acctId.setBounds(94, 24, 129, 21);
		panel.add(acctId);
		acctId.setColumns(10);
		
	
		acctType.setModel(new DefaultComboBoxModel(new String[] {"一卡通账户", "贷款账户", "外汇账户", "信用卡账户"}));
		acctType.setBounds(94, 67, 129, 21);
		panel.add(acctType);
		
		JLabel label_1 = new JLabel("账户类型");
		label_1.setBounds(30, 70, 54, 15);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("存款金额");
		label_2.setBounds(30, 113, 54, 15);
		panel.add(label_2);
		
		saveMoney = new JTextField();
		saveMoney.setBounds(94, 110, 129, 21);
		panel.add(saveMoney);
		saveMoney.setColumns(10);
		
		JLabel label_3 = new JLabel("存款类型");
		label_3.setBounds(242, 27, 54, 15);
		panel.add(label_3);
		
	
		saveType.setModel(new DefaultComboBoxModel(new String[] {"活期", "定期"}));
		saveType.setBounds(296, 24, 75, 21);
		panel.add(saveType);
		
		JLabel label_4 = new JLabel("存款期限");
		label_4.setBounds(242, 70, 54, 15);
		panel.add(label_4);
		
		saveYear = new JTextField();
		saveYear.setBounds(296, 67, 75, 21);
		panel.add(saveYear);
		saveYear.setColumns(10);
		
		JButton button = new JButton("开户");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User user = (User) Container.getValue("user");
				Account a=new Account();
				a.setUserId(user.getUserId());//用户id
				a.setAcctId(acctId.getText());
				a.setAccType(acctType.getSelectedIndex());
				a.setSaveMoney(Double.parseDouble(saveMoney.getText()));
				a.setSaveType(saveType.getSelectedIndex());
				a.setSaveYear(Integer.parseInt(saveYear.getText()));
				
				try {
					accountService.add(a);
					JOptionPane.showMessageDialog(null, "开户成功");
					/////=================================================================
					//CardPanel cardPanel = (CardPanel) Container.getValue("cardPanel");
					//（照着视频）像这里这样写再调用cardPanel.refresh()都是错！！！！！！！！！！！！！！！！！！！！！
					//////======================================
					//cardPanel.refresh();
					CardPanel.refresh();
					JPanel mainJPanel = (JPanel) Container.getValue("mainJPanel");
					CardLayout cardLayout = (CardLayout) mainJPanel.getLayout();
					cardLayout.show(mainJPanel, "cardpanel");
					
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "开户失败，"+e1.getMessage()+"");
				}
				acctId.setText("");
				acctType.setSelectedIndex(0);
				saveMoney.setText("");
				saveType.setSelectedIndex(0);
				saveYear.setText("");
				
			}
		});
		button.setBounds(194, 226, 93, 23);
		add(button);

	}
}
