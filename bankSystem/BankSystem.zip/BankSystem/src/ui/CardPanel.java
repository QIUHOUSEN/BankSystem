/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package ui;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.CardLayout;
import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.JButton;

import bean.Account;
import bean.User;
import service.AccountService;
import serviceImpl.AccountServiceImpl;
import utils.Container;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class CardPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5610127328392382146L;
	static JLabel welcome = new JLabel("欢迎你${}");
	static JComboBox<String> allCards = new JComboBox<>();
	private static AccountService accountService = new AccountServiceImpl();
	
	public CardPanel() {
		setLayout(null);
		
		welcome.setFont(new Font("宋体", Font.PLAIN, 18));
		welcome.setBounds(148, 103, 173, 40);
		add(welcome);
		
		JLabel label = new JLabel("请选择卡片");
		label.setBounds(73, 166, 80, 15);
		add(label);
		
		
		allCards.setBounds(182, 163, 149, 21);
		add(allCards);
		
		JButton okBtn = new JButton("确定");
		okBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String acctId = (String) allCards.getSelectedItem();
				try {
					Account acct = accountService.findByAccountId(acctId);
					Container.register("acct", acct);
					JPanel mainJPanel=(JPanel) Container.getValue("mainJPanel");
					CardLayout card = (CardLayout) mainJPanel.getLayout();
					card.show(mainJPanel, "bankPanel");
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "发生错误原因："+e1.getMessage());
				}
			}
		});
		okBtn.setBounds(87, 256, 93, 23);
		add(okBtn);
		
		JButton newCardBtn = new JButton("开户");
		newCardBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel mainJPanel=(JPanel) Container.getValue("mainJPanel");
				CardLayout card = (CardLayout) mainJPanel.getLayout();
				card.show(mainJPanel, "cardAddPanel");
				
			}
		});
		newCardBtn.setBounds(259, 256, 93, 23);
		add(newCardBtn);
	}
	public static void refresh(){
		User user = (User) Container.getValue("user");
		//System.out.println("用户账号"+user.getPersonId());
		welcome.setText("欢迎你："+user.getUserName());
		allCards.removeAllItems();
		try {
			List<Account> accts = accountService.findAllByUserId(user.getUserId());
			//System.out.println("所有卡片张数："+accts.size());
			if(accts!=null && accts.size()>0){
				for(Account account : accts){
					allCards.addItem(account.getAcctId());
				}
			}						
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
