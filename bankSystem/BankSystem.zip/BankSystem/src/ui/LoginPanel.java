/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package ui;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;

import service.UserService;
import serviceImpl.UserServiceImpl;
import utils.Container;

import java.awt.CardLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextArea;
import javax.swing.JPasswordField;

import bean.User;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class LoginPanel extends JPanel {
	JTextArea userid = new JTextArea();
 	private JPasswordField userpwd;
 	private UserService userService = new UserServiceImpl();
	/**
	 * Create the panel.
	 */
	public LoginPanel() {
		setLayout(null);
		
		JButton loginbtn = new JButton("登 录");
		loginbtn.addActionListener(new ActionListener() {
			User user=null; 
			public void actionPerformed(ActionEvent e) {
				try {
					user = userService.login(userid.getText(), new String(userpwd.getPassword()));
					Container.register("user", user);
					CardPanel cardPanel = (CardPanel) Container.getValue("cardpanel");
					cardPanel.refresh();
					JPanel mainJPanel = (JPanel) Container.getValue("mainJPanel");
					CardLayout cardLayout = (CardLayout) mainJPanel.getLayout();
					cardLayout.show(mainJPanel, "cardpanel");
					
				} catch (Exception e1) {
					e1.printStackTrace();
					if(user==null){
					JOptionPane.showMessageDialog(null,"登录失败，原因："+e1.getMessage()+"");
					//JOptionPane.showMessageDialog(null, "注册失败：填入数据不符规则(如下：)!"+e2.getMessage()+"");
					}
				}
				userid.setText("");
				userpwd.setText("");
			}
		});
		loginbtn.setBounds(67, 277, 93, 23);
		add(loginbtn);
		
		JButton regbtn = new JButton("注 册");
		regbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel mainJPanel = (JPanel) Container.getValue("mainJPanel");
				CardLayout cardLayout = (CardLayout) mainJPanel.getLayout();
				cardLayout.show(mainJPanel, "regPanel");//前面一个是父panel，后面的是要显示的子panel的名字
				
			}
		});
		regbtn.setBounds(245, 277, 93, 23);
		add(regbtn);
		
		JLabel label = new JLabel("银行管理系统");
		label.setFont(new Font("宋体", Font.PLAIN, 18));
		label.setBounds(166, 28, 131, 51);
		add(label);
		
		JLabel label_1 = new JLabel("用户工号");
		label_1.setBounds(67, 94, 54, 15);
		add(label_1);
		
		JLabel label_2 = new JLabel("用户密码");
		label_2.setBounds(67, 160, 54, 15);
		add(label_2);
		
		
		userid.setBounds(152, 90, 145, 24);
		add(userid);
		
		userpwd = new JPasswordField();
		userpwd.setBounds(152, 157, 145, 21);
		add(userpwd);

	}
}
