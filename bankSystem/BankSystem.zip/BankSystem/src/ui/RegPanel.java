/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package ui;

import javax.swing.JPanel;
import javax.swing.JButton;

import service.Rule;
import service.UserService;
import serviceImpl.UserServiceImpl;
import utils.Container;

import java.awt.CardLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import bean.User;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class RegPanel extends JPanel {
 	private JTextField UserId;
 	private JTextField userName;
 	private JTextField personId;
 	private JTextField addr;
 	private JTextField phone;
 	private JPasswordField userPwd;
 	private UserService userService = new UserServiceImpl();
 	JComboBox<String> userType = new JComboBox<>();
 	Rule rule = new Rule();
 	
	/**
	 * Create the panel.
	 */
	public RegPanel() {
		setLayout(null);
		
		JButton regbtn = new JButton("注册");
		regbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User user = new User(UserId.getText(),personId.getText(),userName.getText(),
						new String(userPwd.getPassword()),null,
						phone.getText(),addr.getText(),userType.getSelectedIndex());
				try {
					rule.validateUser(user);
				} catch (Exception e2) {
					// TODO 自动生成的 catch 块
					e2.printStackTrace();
					JOptionPane.showMessageDialog(null, "注册失败：填入数据不符规则(如下：)!"+e2.getMessage()+"");
					UserId.setText("");
					userName.setText("");
					personId.setText("");
					addr.setText("");
					phone.setText("");
					userPwd.setText("");
					return;
				}
				try {
					userService.register(user);
					JOptionPane.showMessageDialog(null, "注册成功", "恭喜", JOptionPane.PLAIN_MESSAGE);
					UserId.setText("");
					userName.setText("");
					personId.setText("");
					addr.setText("");
					phone.setText("");
					userPwd.setText("");
					
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "注册失败，原因如下："+e1.getMessage()+"");
				}
			}
		});
		regbtn.setBounds(54, 277, 93, 23);
		add(regbtn);
		
		JButton backbtn = new JButton("返回");
		backbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel mainJPanel = (JPanel) Container.getValue("mainJPanel");
				CardLayout cardLayout = (CardLayout) mainJPanel.getLayout();
				cardLayout.show(mainJPanel, "loginPanel");
			}
		});
		backbtn.setBounds(226, 277, 93, 23);
		add(backbtn);
		
		JPanel panel = new JPanel();
		panel.setOpaque(false);
		panel.setBorder(new TitledBorder(new LineBorder(new Color(0, 128, 128), 2, true), "\u7528\u6237\u6CE8\u518C", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 0, 0)));
		panel.setBounds(28, 5, 412, 262);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("用户账号");
		lblNewLabel.setBounds(20, 21, 54, 15);
		panel.add(lblNewLabel);
		
		JLabel label = new JLabel("用户姓名");
		label.setBounds(20, 52, 54, 15);
		panel.add(label);
		
		JLabel lblNewLabel_1 = new JLabel("用户密码");
		lblNewLabel_1.setBounds(20, 89, 54, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("身份证");
		lblNewLabel_2.setBounds(20, 124, 54, 15);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("地址");
		lblNewLabel_3.setBounds(20, 155, 54, 15);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("电话号码");
		lblNewLabel_4.setBounds(20, 189, 54, 15);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("账户类型");
		lblNewLabel_5.setBounds(20, 225, 54, 15);
		panel.add(lblNewLabel_5);
		
		UserId = new JTextField();
		UserId.setBounds(117, 18, 168, 21);
		panel.add(UserId);
		UserId.setColumns(10);
		
		userName = new JTextField();
		userName.setColumns(10);
		userName.setBounds(117, 49, 168, 21);
		panel.add(userName);
		
		personId = new JTextField();
		personId.setColumns(10);
		personId.setBounds(117, 121, 168, 21);
		panel.add(personId);
		
		addr = new JTextField();
		addr.setColumns(10);
		addr.setBounds(117, 152, 168, 21);
		panel.add(addr);
		
		phone = new JTextField();
		phone.setColumns(10);
		phone.setBounds(117, 186, 168, 21);
		panel.add(phone);
		
		userPwd = new JPasswordField();
		userPwd.setBounds(117, 86, 168, 21);
		panel.add(userPwd);
		
		
		userType.setModel(new DefaultComboBoxModel<>(new String[] {"系统管理员", "银行职员","储户" }));
		userType.setBounds(117, 222, 168, 21);
		panel.add(userType);

	}
}
