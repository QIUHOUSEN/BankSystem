/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package ui;

import javax.security.auth.Refreshable;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import service.Rule;
import service.UserService;
import serviceImpl.UserServiceImpl;
import sun.org.mozilla.javascript.internal.ast.NewExpression;
import utils.Container;
import bean.User;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class SystemPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2346597198635128980L;
	private JPasswordField pwd;
	private JPasswordField pwd01;
	private JPasswordField pwd02;
	private UserService userService = new UserServiceImpl();

	/**
	 * Create the panel.
	 */
	public SystemPanel() {
		setLayout(null);
		
		JLabel label = new JLabel("原密码：");
		label.setBounds(51, 39, 54, 15);
		add(label);
		
		JLabel label_1 = new JLabel("新密码：");
		label_1.setBounds(51, 92, 54, 15);
		add(label_1);
		
		JLabel label_2 = new JLabel("重复密码：");
		label_2.setBounds(51, 152, 81, 15);
		add(label_2);
		
		pwd = new JPasswordField();
		pwd.setBounds(159, 36, 122, 21);
		add(pwd);
		
		pwd01 = new JPasswordField();
		pwd01.setBounds(159, 89, 122, 21);
		add(pwd01);
		
		pwd02 = new JPasswordField();
		pwd02.setBounds(159, 149, 122, 21);
		add(pwd02);
		
		JButton button = new JButton("更新密码");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User user= (User) Container.getValue("user");
				if(user.getUserPwd().equals(new String(pwd.getPassword()))){
					if(new String(pwd01.getPassword()).equals(new String(pwd01.getPassword()))){
						user.setOldPwd(user.getUserPwd());
						user.setUserPwd(new String(pwd01.getPassword()));
						try {
							Rule.validateUser(user);
							userService.update(user);
							JOptionPane.showMessageDialog(null, "密码修改成功");
							refresh();
						} catch (Exception e1) {
							e1.printStackTrace();
							user.setUserPwd(user.getOldPwd());
							JOptionPane.showMessageDialog(null, "跟新失败,原因："+e1.getMessage());
						}
					}else{
						JOptionPane.showMessageDialog(null, "请确保2次密码一致");
					}
				}else{
					JOptionPane.showMessageDialog(null, "原密码错误");
				}
				
				
			}

			
		});
		button.setBounds(137, 223, 93, 23);
		add(button);

	}
	private void refresh() {
		pwd.setText("");
		pwd01.setText("");
		pwd02.setText("");
	}
}
