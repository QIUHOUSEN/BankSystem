/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package serviceImpl;

import java.util.List;

import com.mysql.jdbc.Connection;

import bean.User;
import dao.UserDao;
import daoImpl.UserDaoImpl;
import service.UserService;
import utils.Dbutil;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class UserServiceImpl implements UserService {
	private UserDao userDao = new UserDaoImpl();
	Connection con=Dbutil.getConnection();
	@Override
	public void register(User user) throws Exception {
		// TODO 自动生成的方法存根
		

	   /* 设置con.setAutoCommit(false)；就是说这个连接不自动提交，你必须手动con.commit();来提交到数据库。
	在默认的情况下con是自动提交的也就是con.setAutoCommit(true);
	   那么为什么要设置是否自动提交呢？是应为某些数据必须同时就行修改，比如说银行的一个转账的操作，
	   必是一个用户上的钱数减少，一个用户上的钱数增加是同时进行的。不能说一个用户上的钱减少了可是另外一个用户上的钱不变……，
	   这种情况下就必须是把con设置为不自动提交，要我们把两段操作信息执行了之后再同时提交上去。
	   要是先把减钱的操作提交了正准备给另外一个用户增加钱的时候系统出现了问题，那么就会出现一个用户的钱数减少了，
	   可是另外一个用户的钱数没有增加的问题。*/
		con.setAutoCommit(false);
		try {
			userDao.addUser(user,con);
			con.commit();
		} catch (Exception e) {
			e.printStackTrace();
			con.rollback();//要是上面提交或者是增加用户出错了，就回滚
		}finally{
			con.close();
		}
		
	}

	@Override
	public void delete(String userId) throws Exception {
		// TODO 自动生成的方法存根
		
	}

	@Override
	public User fingUserById(String userId) throws Exception {
		User user=null;
		con.setAutoCommit(false);
		try {
			user=userDao.findByUserId(userId,con);
			con.commit();
		} catch (Exception e) {
			e.printStackTrace();
			con.rollback();
			if(user==null){
				throw new Exception("数据库没查到此人,null");
			}
		}//finally{
		//	con.close();
		//}
		
		return user;
	}

	@Override
	public List<User> findAll() throws Exception {
		// TODO 自动生成的方法存根
		return null;
	}

	@Override
	public User login(String userId, String userPwd) throws Exception {
		User user=null;
		user = fingUserById(userId);
		//System.out.println(user.getUserId()+" "+user.getUserPwd());
		if(user.getUserId()==null || user.getUserPwd()==null || !user.getUserPwd().equals(userPwd) || !user.getUserId().equals(userId)){
			throw new Exception("登录失败，仔细检查登录信息");
		}
		return user;
	}

	@Override
	public void update(User user) throws Exception {
		// TODO 自动生成的方法存根
		con.setAutoCommit(false);
		try {
			userDao.update(user,con);
			con.commit();
		} catch (Exception e) {
			e.printStackTrace();
			con.rollback();//要是上面提交或者是增加用户出错了，就回滚
		}finally{
			con.close();
		}
	}
	
}
