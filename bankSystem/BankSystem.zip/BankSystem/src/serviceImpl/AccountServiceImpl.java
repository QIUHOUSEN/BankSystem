/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package serviceImpl;

import java.util.List;

import com.mysql.jdbc.Connection;

import dao.AccountDao;
import daoImpl.AccountDaoImpl;
import bean.Account;
import bean.User;
import service.AccountService;
import service.Rule;
import utils.Dbutil;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class AccountServiceImpl implements AccountService {
	private AccountDao acctDao=new AccountDaoImpl();
	@Override
	public void add(Account a) throws Exception {
		// TODO 自动生成的方法存根
		Rule.validateAcct(a);
		Account account=findByAccountId(a.getAcctId());
		System.out.println("账户ID："+account.getAcctId());
		if(account.getAcctId()!=null){
			throw new Exception("该卡号已存在");
		}
			Connection con=Dbutil.getConnection();
			con.setAutoCommit(false);
			acctDao.add(a, con);
			con.commit();
			//con.close();
		
		/*if(account.getAcctId()==null){
			Connection con=Dbutil.getConnection();
			con.setAutoCommit(false);
			acctDao.add(a, con);
			con.commit();
			con.close();
		}
		else if(account!=null){
			
		}*/
		
	}

	@Override
	public void delete(String accId) throws Exception {
		// TODO 自动生成的方法存根
		Connection con=Dbutil.getConnection();
		con.setAutoCommit(false);
		acctDao.delete(accId, con);
		con.commit();
		con.close();
	}

	@Override
	public void update(Account a) throws Exception {
		// TODO 自动生成的方法存根
		Connection con=Dbutil.getConnection();
		con.setAutoCommit(false);
		acctDao.update(a, con);
		con.commit();
		con.close();
	}

	@Override
	public Account findByAccountId(String accId) throws Exception {
		// TODO 自动生成的方法存根
		Connection con=Dbutil.getConnection();
		con.setAutoCommit(false);
		Account account = acctDao.findByAccountId(accId, con);
		con.commit();
		//con.close();
		return account;
	}

	@Override
	public List<Account> findAllByUserId(String userId) throws Exception {
		// TODO 自动生成的方法存根
		Connection con=Dbutil.getConnection();
		con.setAutoCommit(false);
		List<Account> list = acctDao.findAllByUserId(userId, con);
		con.commit();
		//con.close();
		return list;
	}

	@Override
	public void transfer(Account acct, Account acct2) throws Exception {
		// TODO 自动生成的方法存根
		Connection con=Dbutil.getConnection();
		con.setAutoCommit(false);
		acctDao.update(acct2, con);
		acctDao.update(acct, con);
		con.commit();
	}
}
