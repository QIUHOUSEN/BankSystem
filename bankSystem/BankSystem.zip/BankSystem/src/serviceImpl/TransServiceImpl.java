/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package serviceImpl;

import java.util.List;

import bean.TransInfo;

import com.mysql.jdbc.Connection;
import com.sun.jndi.cosnaming.CNCtx;

import dao.TransDao;
import daoImpl.TransDaoImpl;
import service.TransService;
import utils.Dbutil;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class TransServiceImpl implements TransService{
	TransDao transDao = new TransDaoImpl();
	@Override
	public void add(TransInfo a) throws Exception {
		// TODO 自动生成的方法存根
		Connection con=Dbutil.getConnection();
		con.setAutoCommit(false);
		transDao.add(a, con);
		con.commit();
		//con.close();	
	}

	@Override
	public List<TransInfo> findAll() throws Exception {
		// TODO 自动生成的方法存根
		Connection con=Dbutil.getConnection();
		con.setAutoCommit(false);
		List<TransInfo> infos = transDao.findAll(con);
		con.commit();
		//con.close();	
		return infos;
	}
	
	
}
