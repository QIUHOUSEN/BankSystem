/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package bean;

import java.util.Date;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class Account {
	private int id; //
	private String acctId;//账户ID
	private String userId; //用户ID
	private int accType;//账户类型   0： 一卡通  1： 贷款  2： 外汇   3：信用
	private int isLoss; //
	
	private double saveMoney;//存款金额
	private int saveType; //存款类型
	private int saveYear; //存款期限
	private Date saveDate=new Date();//存款日期
	
	private double loanMoney;//贷款金额
	private int loanType;//贷款类型
	private int loanYear;//贷款期限
	private Date loanDate = new Date();//贷款日期
	private String warrant01; //担保2
	private String warrant02;//担保1
	private String loanHouse; //质押房屋
	
	private double creditMoney;//信用额度
	private double consumeMoney;//消费金额
	private String creditPwd;//信用卡密码
	
	private double US_dollar;//美元余额
	private double HK_dollar;//港币
	private double JP_dollar;//日元
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAcctId() {
		return acctId;
	}
	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getAccType() {
		return accType;
	}
	public void setAccType(int accType) {
		this.accType = accType;
	}
	public int getIsLoss() {
		return isLoss;
	}
	public void setIsLoss(int isLoss) {
		this.isLoss = isLoss;
	}
	public double getSaveMoney() {
		return saveMoney;
	}
	public void setSaveMoney(double saveMoney) {
		this.saveMoney = saveMoney;
	}
	public int getSaveType() {
		return saveType;
	}
	public void setSaveType(int saveType) {
		this.saveType = saveType;
	}
	public int getSaveYear() {
		return saveYear;
	}
	public void setSaveYear(int saveYear) {
		this.saveYear = saveYear;
	}
	public Date getSaveDate() {
		return saveDate;
	}
	public void setSaveDate(Date saveDate) {
		this.saveDate = saveDate;
	}
	public double getLoanMoney() {
		return loanMoney;
	}
	public void setLoanMoney(double loanMoney) {
		this.loanMoney = loanMoney;
	}
	public int getLoanType() {
		return loanType;
	}
	public void setLoanType(int loanType) {
		this.loanType = loanType;
	}
	public int getLoanYear() {
		return loanYear;
	}
	public void setLoanYear(int loanYear) {
		this.loanYear = loanYear;
	}
	public Date getLoanDate() {
		return loanDate;
	}
	public void setLoanDate(Date loanDate) {
		this.loanDate = loanDate;
	}
	public String getWarrant01() {
		return warrant01;
	}
	public void setWarrant01(String warrant01) {
		this.warrant01 = warrant01;
	}
	public String getWarrant02() {
		return warrant02;
	}
	public void setWarrant02(String warrant02) {
		this.warrant02 = warrant02;
	}
	public String getLoanHouse() {
		return loanHouse;
	}
	public void setLoanHouse(String loanHouse) {
		this.loanHouse = loanHouse;
	}
	public double getCreditMoney() {
		return creditMoney;
	}
	public void setCreditMoney(double creditMoney) {
		this.creditMoney = creditMoney;
	}
	public double getConsumeMoney() {
		return consumeMoney;
	}
	public void setConsumeMoney(double consumeMoney) {
		this.consumeMoney = consumeMoney;
	}
	public String getCreditPwd() {
		return creditPwd;
	}
	public void setCreditPwd(String creditPwd) {
		this.creditPwd = creditPwd;
	}
	public double getUS_dollar() {
		return US_dollar;
	}
	public void setUS_dollar(double uS_dollar) {
		US_dollar = uS_dollar;
	}
	public double getHK_dollar() {
		return HK_dollar;
	}
	public void setHK_dollar(double hK_dollar) {
		HK_dollar = hK_dollar;
	}
	public double getJP_dollar() {
		return JP_dollar;
	}
	public void setJP_dollar(double jP_dollar) {
		JP_dollar = jP_dollar;
	}
	
	
}
