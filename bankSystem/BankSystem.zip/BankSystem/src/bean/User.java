/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package bean;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class User {
	private String UserId;//用户Id
	private String personId;
	private String userName;//用户名字
	private String userPwd;//用户密码
	private String oldPwd;
	private String phone;
	private String addr;
	private int userType;//0是系统管理员 1是银行职员 2是储户
	
	public User(String userId, String personId, String userName, String userPwd,
			String oldPwd, String phone, String addr, int userType) {
		super();
		UserId = userId;
		this.personId = personId;
		this.userName = userName;
		this.userPwd = userPwd;
		this.oldPwd = oldPwd;
		this.phone = phone;
		this.addr = addr;
		this.userType = userType;
	}
	public User() {
		// TODO 自动生成的构造函数存根
	}
	public String getUserId() {
		return UserId;
	}
	public void setUserId(String userId) {
		UserId = userId;
	}
	public String getPersonId() {
		return personId;
	}
	public void setPersonId(String personId) {
		this.personId = personId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getOldPwd() {
		return oldPwd;
	}
	public void setOldPwd(String oldPwd) {
		this.oldPwd = oldPwd;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public int getUserType() {
		return userType;
	}
	public void setUserType(int userType) {
		this.userType = userType;
	}
	
}
