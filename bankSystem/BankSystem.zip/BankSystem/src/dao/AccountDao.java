/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package dao;

import java.util.List;

import com.mysql.jdbc.Connection;

import bean.Account;
import bean.User;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public interface AccountDao {
	public void add(Account a, Connection con) throws Exception;
	public void delete(String accId, Connection con) throws Exception;
	public void update(Account a, Connection con) throws Exception;
	//根据account的id找到这样一个账户
	public Account findByAccountId(String accId, Connection con) throws Exception;
	//根据用户的Id找到这个用户下的属于这个用户的所有卡片
	public List<Account> findAllByUserId(String userId, Connection con) throws Exception;
	
}
