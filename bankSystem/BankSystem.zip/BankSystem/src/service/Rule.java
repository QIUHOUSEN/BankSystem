/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package service;

import bean.Account;
import bean.User;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class Rule {
	public static void validateAcct(Account acct) throws Exception{
		
	}
	
	
	//校验规则
	public static void validateUser(User user) throws Exception{
		String userId = user.getUserId();
		if(userId.length()!=5){
			throw new Exception("工号只能是5位");
		}
		for(int i=0;i<userId.length();i++){
			if(!Character.isDigit(userId.charAt(i))){
				throw new Exception("工号不符合规则(只能是数字)");
			}
		}
		if(user.getUserPwd().length()<8 || user.getUserPwd().length()>16){
			throw new Exception("用户密码长度不对");
		}
		boolean hasDigit = false;//有无数字
		boolean hasLetter = false;//有无字母
		for(int i=0;i<user.getUserPwd().length();i++){
			if(Character.isDigit(user.getUserPwd().charAt(i))){
				hasDigit=true;
			}
			if(Character.isLetter(user.getUserPwd().charAt(i))){
				hasLetter=true;
			}
		}
		if(hasDigit && hasLetter){
			//不处理（密码有数字和字母）
		}else{
			throw new Exception("密码必须同时包含数字和字母");
		}
		if(user.getUserPwd().contains(user.getUserId())){
			throw new Exception("密码不能包含工号");
		}
	}
	
}
