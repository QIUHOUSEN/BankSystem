/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package daoImpl;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import dao.UserDao;
import utils.Dbutil;
import bean.User;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class UserDaoImpl implements UserDao {
	Connection con=null;
	public Boolean addUser(User user, Connection con) {
		String userid = user.getUserId();
		String personid = user.getPersonId();
		String username = user.getUserName();
		String userpwd = user.getUserPwd();
		String useroldpwd= user.getOldPwd();
		String usertphone= user.getPhone();
		String useraddr= user.getAddr();
		String usertype= user.getUserType()+"";
		String sql="insert into t_user(UserId,personId,userName,userPwd,oldPwd,phone,addr,userType) values(?,?,?,?,?,?,?,?)";
		String[] temp={userid,personid,username,userpwd,useroldpwd,usertphone,useraddr,usertype};
		Dbutil.executeUpdate(sql, temp);
		return true;
	}
	@Override
	public User findByUserId(String userId, Connection con) throws Exception{
		String sql="select *from t_user where UserId="+userId+"";
		PreparedStatement ps=null;
		ResultSet rs = null;
		User user = new User();
		//con.setAutoCommit(false);
		
		ps = (PreparedStatement) con.prepareStatement(sql);
		rs = ps.executeQuery();
		while(rs.next()){
			user.setUserId(rs.getString("UserId"));
			user.setPersonId(rs.getString("personId"));
			user.setUserName(rs.getString("userName"));
			user.setUserPwd(rs.getString("userPwd"));
			user.setOldPwd(rs.getString("oldPwd"));
			user.setPhone(rs.getString("phone"));
			user.setAddr(rs.getString("addr"));
			user.setUserType(rs.getInt("userType"));
		}
		return user;
	}
	@Override
	public void update(User user, Connection con) throws Exception {
		// TODO 自动生成的方法存根
		String sql="update t_user set userPwd=? where UserId=?";
		PreparedStatement ps=(PreparedStatement) con.prepareStatement(sql);
		ps.setString(1, user.getUserPwd());
		ps.setString(2, user.getUserId());
		ps.executeUpdate();
	}
	
}
