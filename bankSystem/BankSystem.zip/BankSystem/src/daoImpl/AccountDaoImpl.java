/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package daoImpl;

import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import sun.security.util.Password;
import utils.Dbutil;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import bean.Account;
import bean.User;
import dao.AccountDao;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class AccountDaoImpl implements AccountDao {
	Connection con;
	@Override
	public void add(Account a, Connection con) throws Exception {
		// TODO 自动生成的方法存根
		String sql="insert into t_account(acctId,userId,accType,isLoss,saveMoney,"
+ "saveType,saveYear,saveDate,loanMoney,loanType,loanYear,loanDate,warrant01,"
+ "warrant02,loanHouse,creditMoney,consumemoney,creditPwd,US_dollar,HK_dollar,JP_dollar) "
+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
		ps.setString(1, a.getAcctId());
		ps.setString(2, a.getUserId());
		ps.setInt(3, a.getAccType());
		ps.setInt(4, a.getIsLoss());
		ps.setDouble(5, a.getSaveMoney());
		ps.setInt(6, a.getSaveType());
		ps.setInt(7, a.getSaveYear());
		ps.setDate(8, new java.sql.Date(a.getSaveDate().getTime()));
		ps.setDouble(9, a.getLoanMoney());
		ps.setInt(10, a.getLoanType());
		ps.setInt(11, a.getLoanYear());
		ps.setDate(12, new java.sql.Date(a.getLoanDate().getTime()));
		ps.setString(13, a.getWarrant01());
		ps.setString(14, a.getWarrant02());
		ps.setString(15, a.getLoanHouse());
		ps.setDouble(16, a.getCreditMoney());
		ps.setDouble(17, a.getConsumeMoney());
		ps.setString(18, a.getCreditPwd());
		ps.setDouble(19, a.getUS_dollar());
		ps.setDouble(20, a.getHK_dollar());
		ps.setDouble(21, a.getJP_dollar());
		ps.executeUpdate();
	}

	@Override
	public void delete(String accId, Connection con) throws Exception {
		// TODO 自动生成的方法存根
		
	}

	@Override
	public void update(Account a, Connection con) throws Exception {
		// TODO 自动生成的方法存根
		String sql="update t_account set acctId=?,userId=?,accType=?,isLoss=?,saveMoney=?,"
				+ "saveType=?,saveYear=?,saveDate=?,loanMoney=?,loanType=?,loanYear=?,loanDate=?,warrant01=?,"
				+ "warrant02=?,loanHouse=?,creditMoney=?,consumemoney=?,creditPwd=?,US_dollar=?,HK_dollar=?,JP_dollar=?"
				+ "where acctId='"+a.getAcctId()+"'";
		PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
		ps.setString(1, a.getAcctId());
		ps.setString(2, a.getUserId());
		ps.setInt(3, a.getAccType());
		ps.setInt(4, a.getIsLoss());
		ps.setDouble(5, a.getSaveMoney());
		ps.setInt(6, a.getSaveType());
		ps.setInt(7, a.getSaveYear());
		ps.setDate(8, new Date(a.getSaveDate().getTime()));
		ps.setDouble(9, a.getLoanMoney());
		ps.setInt(10, a.getLoanType());
		ps.setInt(11, a.getLoanYear());
		ps.setDate(12, new Date(a.getLoanDate().getTime()));
		ps.setString(13, a.getWarrant01());
		ps.setString(14, a.getWarrant02());
		ps.setString(15, a.getLoanHouse());
		ps.setDouble(16, a.getCreditMoney());
		ps.setDouble(17, a.getConsumeMoney());
		ps.setString(18, a.getCreditPwd());
		ps.setDouble(19, a.getUS_dollar());
		ps.setDouble(20, a.getHK_dollar());
		ps.setDouble(21, a.getJP_dollar());
		ps.executeUpdate();
		
		
	}

	@Override
	public Account findByAccountId(String accId, Connection con) throws Exception {
		// TODO 自动生成的方法存根
		/*String sql="select acctId,userId,accType,isLoss,saveMoney,"
				+ "saveType,saveYear,saveDate,loanMoney,loanType,loanYear,loanDate,warrant01,"
				+ "warrant02,loanHouse,creditMoney,consumemoney,creditPwd,US_dollar,HK_dollar,JP_dollar"
				+ "from t_account where acctId=?";*/
		String sql="select *from t_account where acctId=?";
		PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
		ps.setString(1, accId);
		ResultSet rs=ps.executeQuery();
		Account a = new Account();
		while(rs.next()){
			a.setId(Integer.parseInt(rs.getString(1)));
			a.setAcctId(rs.getString(2));
			a.setUserId(rs.getString(3));
			//System.out.println(rs.getString(3));
			a.setAccType(rs.getInt(4));
			a.setIsLoss(rs.getInt(5));
			a.setSaveMoney(rs.getDouble(6));
			//System.out.println(rs.getDouble(5));
			a.setSaveType(rs.getInt(7));
			a.setSaveYear(rs.getInt(8));
			//System.out.println(rs.getDate(8));
			a.setSaveDate(rs.getDate(9));
			a.setLoanMoney(rs.getDouble(10));
			a.setLoanType(rs.getInt(11));
			a.setLoanYear(rs.getInt(12));
			a.setLoanDate(rs.getDate(13));
			a.setWarrant01(rs.getString(14));
			a.setWarrant02(rs.getString(15));
			a.setLoanHouse(rs.getString(16));
			a.setCreditMoney(rs.getDouble(17));
			a.setConsumeMoney(rs.getDouble(18));
			a.setCreditPwd(rs.getString(19));
			a.setUS_dollar(rs.getDouble(20));
			a.setHK_dollar(rs.getDouble(21));
			a.setJP_dollar(rs.getDouble(22));
			
		}
		return a;
	}

	@Override
	public List<Account> findAllByUserId(String userId, Connection con) throws Exception {
		// TODO 自动生成的方法存根
		List<Account> accts=new ArrayList<Account>();
		/*String sql="select acctId,userId,accType,isLoss,saveMoney,"
				+ "saveType,saveYear,saveDate,loanMoney,loanType,loanYear,loanDate,warrant01,"
				+ "warrant02,loanHouse,creditMoney,consumemoney,creditPwd,US_dollar,HK_dollar,JP_dollar"
				+ "from t_account where userId=?";*/
		String sql="select *from t_account where userId=?";
		PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
		ps.setString(1, userId);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Account a = new Account();
			a.setId(rs.getInt(1));
			a.setAcctId(rs.getString(2));
			a.setUserId(rs.getString(3));
			a.setAccType(rs.getInt(4));
			a.setIsLoss(rs.getInt(5));
			a.setSaveMoney(rs.getDouble(6));
			a.setSaveType(rs.getInt(7));
			a.setSaveYear(rs.getInt(8));
			a.setSaveDate(rs.getDate(9));
			a.setLoanMoney(rs.getDouble(10));
			a.setLoanType(rs.getInt(11));
			a.setLoanYear(rs.getInt(12));
			a.setLoanDate(rs.getDate(13));
			a.setWarrant01(rs.getString(14));
			a.setWarrant02(rs.getString(15));
			a.setLoanHouse(rs.getString(16));
			a.setCreditMoney(rs.getDouble(17));
			a.setConsumeMoney(rs.getDouble(18));
			a.setCreditPwd(rs.getString(19));
			a.setUS_dollar(rs.getDouble(20));
			a.setHK_dollar(rs.getDouble(21));
			a.setJP_dollar(rs.getDouble(22));
			accts.add(a);
			
		}
		return accts;
	}
	
}
