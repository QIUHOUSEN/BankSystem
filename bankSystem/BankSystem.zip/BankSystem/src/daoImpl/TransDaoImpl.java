/*
 * Copyright (C) 2014 0xC000005 <flexie@foxmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


package daoImpl;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import utils.Dbutil;
import bean.TransInfo;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import dao.TransDao;

 /**
 * <p>公共方法类</p>
 *
 * @author 0xC000005
 * @version 1.0
 */

public class TransDaoImpl implements TransDao {
	
	@Override
	public void add(TransInfo t, Connection con) throws Exception {
		// TODO 自动生成的方法存根
		String sql="insert into t_transinfo(userId,acctNo,money,transType,transDate) "
				+ "values(?,?,?,?,?)";
		PreparedStatement ps=(PreparedStatement) con.prepareStatement(sql);
		//System.out.println(t.getAcctNo());
		ps.setString(1, t.getUserId());
		ps.setString(2, t.getAcctNo());
		ps.setDouble(3, t.getMoney());
		ps.setString(4, t.getTransType());
		//ps.setDate(5, new java.sql.Date(t.getTransDate().getTime()));
		ps.setTimestamp(5, new Timestamp(t.getTransDate().getTime()));
		ps.executeUpdate();
	}

	@Override
	public List<TransInfo> findAll(Connection con) throws Exception {
		// TODO 自动生成的方法存根
		List<TransInfo> trans=new ArrayList<TransInfo>();
		String sql="select *from t_transinfo order by transDate desc";
		PreparedStatement ps=(PreparedStatement) con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			TransInfo a=new TransInfo();
			a.setId(rs.getInt(1));
			a.setUserId(rs.getString(2));
			a.setAcctNo(rs.getString(3));
			a.setMoney(rs.getDouble(4));
			a.setTransType(rs.getString(5));
			a.setTransDate(rs.getDate(6));
			trans.add(a);
		}
		
		return trans;
	}

}
